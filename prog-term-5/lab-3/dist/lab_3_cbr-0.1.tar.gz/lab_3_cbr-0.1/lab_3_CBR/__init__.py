from .currency_rates import CurrencyRates
from .singleton import Singleton