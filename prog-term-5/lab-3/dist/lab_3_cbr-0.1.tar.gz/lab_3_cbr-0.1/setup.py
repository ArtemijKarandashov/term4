from setuptools import setup

setup(name='lab_3_CBR',
      version='0.1',
      description='Test package',
      packages=['lab_3_CBR'],
      author_email='artemij.karandashov@yandex.ru',
      zip_safe=False)